function toggleMenu(){
    var headerMenu =  document.getElementById('main-menu');

    if(headerMenu.className == 'show') {
        headerMenu.className = 'hide';
    }else {
        headerMenu.className = 'show';
    }
}